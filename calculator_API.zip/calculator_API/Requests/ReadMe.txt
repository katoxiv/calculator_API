Install requests package from python pip by running,
pip install requests


===============================================

Ready to go
Send all requsts you wish.