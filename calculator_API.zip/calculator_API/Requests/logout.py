import requests

url = 'http://localhost:8080/logout'

response = requests.get(url)
print(response.json())
