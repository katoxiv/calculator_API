import requests

url = 'http://127.0.0.1:8080/login'
data = {
    'username': 'jamesbond',
    'password': 'casinoRoyale&21'
}

response = requests.post(url, json=data)
print(response.json())
