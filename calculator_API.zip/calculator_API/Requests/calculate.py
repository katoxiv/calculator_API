import requests

s = requests.Session()

# login
login_url = 'http://127.0.0.1:8080/login'
login_data = {
    'username': 'jamesbond',
    'password': 'casinoRoyale&21'
}
s.post(login_url, json=login_data)

# calculate
calculate_url = 'http://127.0.0.1:8080/calculate'
calculate_data = {
    'expression': '3 * 5 + 2'
}
response = s.post(calculate_url, json=calculate_data)

print(response.json())
