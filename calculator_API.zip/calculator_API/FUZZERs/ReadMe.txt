For each fuzzer, I have included a documentation script you should read for better understanding.
Enjoy testing.