In structions on how to get started ::

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

1. Create the folder which is to be your virtual environment.

2. Make sure you have installed Python your machine.

3. Pip install virtualenv package from python.

4. Open command prompt and navigate to the folder using cd

5. And now finally, run the command    python -m venv .

6. Drop the files run.py, requirements.txt and the folder myapp in this create virtual environment.

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

The virtual environment is then created.
If you want to activate and start working in it



.\Scripts\activate    on cmd

Now, you can install Python packages using pip and they will only be available inside this virtual environment.

The following command       pip install -r requirements.txt   will install all necessary python libraries into the virtual environment.



And after workin in it, deactivating is done by running, 

deactivate




Note

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Remember, every time you want to work on your project, you should activate the virtual environment and deactivate it when you're done.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



After Creating the VIRTUAL ENVIRONMENT as the steps above show,

Create a database by doing :::


From the terminal,
Navigate to the virtual environment using cd


Run the command
set FLASK_APP=myapp


Then create a migration repository by running,
flask db init
This will add a migrations folder in the virtual environment


Then generate an initial migration by running,
flask db migrate -m "Initial migration."


Then you can apply the changes described by the migration script to your database through this command,
flask db upgrade


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


Now you have a virtual environment with a database created in it.
Ready to run the application.


BY runnung ::::
python run.py in command prompt
You will have successfully deployed the API on the port selected in the code.